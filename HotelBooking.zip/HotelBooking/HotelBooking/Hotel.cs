﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HotelBooking
{
    public class Hotel
    {
        public static string RoomAvailabilityCheck(int roomSize, int stardDayBooingIndex, int endDayBooingIndex, IList<IList<bool>> availableBookingSlots)
        {
            string ret = "";
            try
            {
                if (stardDayBooingIndex < 0 || endDayBooingIndex < 0 || stardDayBooingIndex > 365 || endDayBooingIndex > 365)
                {
                    return "Decline";
                }
                if (stardDayBooingIndex > endDayBooingIndex)
                {
                    return "End Data is grater then StartDate";
                }
                int roomNo = GetRoomItem(stardDayBooingIndex, endDayBooingIndex, availableBookingSlots, roomSize);
                if (roomNo >= 0)
                {
                    UpdateRoomBooking(roomNo, stardDayBooingIndex, endDayBooingIndex, availableBookingSlots);
                    ret = "Booking accepted against Room no. " + (roomNo + 1);
                }
                else
                {
                    ret = "Booking declined";
                }
                return ret;
            }
            catch (Exception ex)
            {
                throw new Exception("Method RoomAvailabilityCheck execution failed due to:- " + ex.Message.ToString());
            }

        }
        private static void UpdateRoomBooking(int roomNo, int startDateBookingIndex, int endDateBookingIndex, IList<IList<bool>> source)
        {
            try
            {
                for (int j = startDateBookingIndex; j <= endDateBookingIndex; j++)
                {
                    source[roomNo][j] = true;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Method UpdateRoomBooking execution failed due to:- " + ex.Message.ToString());
            }
        }
        public static IList<IList<bool>> GetBookingData(int noOfRoom, int noOfDays)
        {
            IList<IList<bool>> source = new List<IList<bool>>();
            try
            {
                for (int i = 0; i < noOfRoom; i++)
                {
                    List<bool> day = new List<bool>();
                    for (int j = 0; j < noOfDays; j++)
                    {
                        day.Add(false);
                    }
                    source.Add(day);
                }
                return source;
            }
            catch (Exception ex)
            {
                throw new Exception("Method GetDatatable execution failed due to:- " + ex.Message.ToString());
            }
        }
        private static int GetRoomItem(int startDateBookingIndex, int endDateBookingIndex, IList<IList<bool>> source, int noOfRoom)
        {
            bool found = false;
            int roomNo = -1;
            int lastBookedDay = 0;
            try
            {
                for (int i = 0; i < noOfRoom; i++)
                {
                    for (int j = startDateBookingIndex; j <= endDateBookingIndex; j++)
                    {
                        found = true;
                        if (source[i][j])
                        {
                            found = false;
                            j = endDateBookingIndex + 1;
                        }
                    }
                    if (found)
                    {
                        int closet = 0;
                        for (int j = startDateBookingIndex - 1; j >= 0; j--)
                        {
                            if (source[i][j])
                            {
                                closet = j;
                                j = -1;
                            }
                        }
                        if ((startDateBookingIndex - closet) == 1)
                        {
                            return i;
                        }
                        else if ((startDateBookingIndex - closet) <= (startDateBookingIndex - lastBookedDay))
                        {
                            lastBookedDay = closet;
                            roomNo = i;
                        }
                    }
                }
                return roomNo;
            }
            catch (Exception ex)
            {
                throw new Exception("Method GetRoomItem execution failed due to:- " + ex.Message.ToString());
            }
        }

    }
}
