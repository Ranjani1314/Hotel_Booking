﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;

namespace HotelBooking
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to Online Hotel Reservation System\n");

            string roomsize = string.Empty;
            string startDay = string.Empty;
            string endDay = string.Empty;

            try
            {
            STEP0:
                Console.WriteLine("Please enter room size");
                roomsize = Console.ReadLine();
                if (!roomsize.IsNnmber())
                {
                    Console.WriteLine("Enter a valid room size number");
                    goto STEP0;
                }
                if (Convert.ToInt32(roomsize) > 1000 || Convert.ToInt32(roomsize) < 1)
                 {
                   Console.WriteLine("RoomSize should be between 1 and 1000");
                    goto STEP0;
                 }
                    List<Tuple<int, int>> bookingdays = new List<Tuple<int, int>>();
                var data = Hotel.GetBookingData(Convert.ToInt32(roomsize), 365);
            STEP1:
                Console.WriteLine("\nEnter Start Day");
                startDay = Console.ReadLine();

                if (!startDay.IsNnmber())
                {
                    Console.WriteLine("Please enter a valid start day");
                    goto STEP1;
                }

            STEP2:
                Console.WriteLine("Enter End Day");
                endDay = Console.ReadLine();

                if (!endDay.IsNnmber())
                {
                    Console.WriteLine("Please enter a valid end day");
                    goto STEP2;
                }

                string result = Hotel.RoomAvailabilityCheck(Convert.ToInt32(roomsize), Convert.ToInt32(startDay), Convert.ToInt32(endDay), data);
                Console.WriteLine(result);
                goto STEP1;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Something went wrong. Not able to book due to:- " + ex.Message.ToString());
                Console.ReadLine();
            }
        }
    }
    public static class Helper
    {
        public static bool IsNnmber(this string input)
        {
            int output = 0;
            return int.TryParse(input, out output);
        }

    }
}
