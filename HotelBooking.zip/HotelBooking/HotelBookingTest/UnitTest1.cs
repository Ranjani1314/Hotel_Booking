﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using HotelBooking;
using System.Data;
using System.Collections.Generic;

namespace HotelBookingTest
{
    [TestClass]
    public class UnitTest1
    {
        HotelBooking.Hotel objhotel = new HotelBooking.Hotel();

        [TestMethod]
        public void TestMethod1()
        {
            //Roomsize 1
            var bookingSlot = Hotel.GetBookingData(1, 365);
            List<Tuple<int, int, string>> lstTuples = new List<Tuple<int, int, string>>();
            lstTuples.Add(new Tuple<int, int, string>(-4, 2, "Decline"));
            lstTuples.Add(new Tuple<int, int, string>(200, 400, "Decline"));

            foreach (var bookingReq in lstTuples)
            {
               string bookingresult= Hotel.RoomAvailabilityCheck(1, bookingReq.Item1, bookingReq.Item2, bookingSlot);
                Assert.AreEqual(bookingresult, bookingReq.Item3);
            }

        }
        [TestMethod]
        public void TestMethod2()
        {
            //Room Size:3
            var bookingSlot = Hotel.GetBookingData(3, 365);
            List<Tuple<int, int, string>> lstTuples = new List<Tuple<int, int, string>>();
            lstTuples.Add(new Tuple<int, int, string>(0, 5, "Booking accepted against Room no. 3"));
            lstTuples.Add(new Tuple<int, int, string>(7, 13, "Booking accepted against Room no. 3"));
            lstTuples.Add(new Tuple<int, int, string>(3, 9, "Booking accepted against Room no. 2"));
            lstTuples.Add(new Tuple<int, int, string>(5, 7, "Booking accepted against Room no. 1"));
            lstTuples.Add(new Tuple<int, int, string>(6, 6, "Booking accepted against Room no. 3"));
            lstTuples.Add(new Tuple<int, int, string>(0, 4, "Booking accepted against Room no. 1"));


            foreach (var bookingReq in lstTuples)
            {
                string bookResult = Hotel.RoomAvailabilityCheck(3, bookingReq.Item1, bookingReq.Item2, bookingSlot);
                Assert.AreEqual(bookingReq.Item3, bookResult);
            }

        }
        [TestMethod]
        public void TestMethod3()
        {
            //Room Size:3
            var bookingSlot = Hotel.GetBookingData(3, 365);

            List<Tuple<int, int, string>> lstTuples = new List<Tuple<int, int, string>>();
            lstTuples.Add(new Tuple<int, int, string>(1, 3, "Booking accepted against Room no. 1"));
            lstTuples.Add(new Tuple<int, int, string>(2, 5, "Booking accepted against Room no. 3"));
            lstTuples.Add(new Tuple<int, int, string>(1, 9, "Booking accepted against Room no. 2"));
            lstTuples.Add(new Tuple<int, int, string>(0, 15, "Booking declined"));

            foreach (var bookingReq in lstTuples)
            {
                string bookResult = Hotel.RoomAvailabilityCheck(3, bookingReq.Item1, bookingReq.Item2, bookingSlot);
                Assert.AreEqual(bookingReq.Item3, bookResult);
            }
        }
        [TestMethod]
        public void TestMethod4()
        {
            //Room Size:3
            var bookingSlot = Hotel.GetBookingData(3, 365);
            List<string> lstBook1 = new List<string>();
            List<Tuple<int, int, string>> lstTuples = new List<Tuple<int, int, string>>();
            lstTuples.Add(new Tuple<int, int, string>(1, 3, "Booking accepted against Room no. 1"));
            lstTuples.Add(new Tuple<int, int, string>(0, 15, "Booking accepted against Room no. 3"));
            lstTuples.Add(new Tuple<int, int, string>(1, 9, "Booking accepted against Room no. 2"));
            lstTuples.Add(new Tuple<int, int, string>(2, 5, "Booking declined"));
            lstTuples.Add(new Tuple<int, int, string>(4, 9, "Booking accepted against Room no. 1"));

            foreach (var bookingReq in lstTuples)
            {
                string bookResult = Hotel.RoomAvailabilityCheck(3, bookingReq.Item1, bookingReq.Item2, bookingSlot);
                Assert.AreEqual(bookingReq.Item3, bookResult);
            }
        }
        [TestMethod]
        public void TestMethod5()
        {
            //Room Size:2
            var bookingSlot = Hotel.GetBookingData(2, 365);

            List<Tuple<int, int, string>> lstTuples = new List<Tuple<int, int, string>>();
            lstTuples.Add(new Tuple<int, int, string>(1, 3, "Booking accepted against Room no. 1"));
            lstTuples.Add(new Tuple<int, int, string>(0, 4, "Booking accepted against Room no. 2"));
            lstTuples.Add(new Tuple<int, int, string>(2, 3, "Booking declined"));
            lstTuples.Add(new Tuple<int, int, string>(5, 5, "Booking accepted against Room no. 2"));
            lstTuples.Add(new Tuple<int, int, string>(4, 10, "Booking accepted against Room no. 1"));
            lstTuples.Add(new Tuple<int, int, string>(10, 10, "Booking accepted against Room no. 2"));
            lstTuples.Add(new Tuple<int, int, string>(6, 7, "Booking accepted against Room no. 2"));
            lstTuples.Add(new Tuple<int, int, string>(8, 10, "Booking declined"));
            lstTuples.Add(new Tuple<int, int, string>(8, 9, "Booking accepted against Room no. 2"));

            foreach (var bookingReq in lstTuples)
            {
                string bookResult = Hotel.RoomAvailabilityCheck(2, bookingReq.Item1, bookingReq.Item2, bookingSlot);
                Assert.AreEqual(bookingReq.Item3, bookResult);
            }
        }

        [TestMethod]
        public void TestMethod6()
        {
            //Room Size:1000
            var bookingSlot = Hotel.GetBookingData(1000, 365);

            List<Tuple<int, int, string>> lstTuples = new List<Tuple<int, int, string>>();
            lstTuples.Add(new Tuple<int, int, string>(2, 4, "Booking accepted against Room no. 1000"));
            lstTuples.Add(new Tuple<int, int, string>(2, 4, "Booking accepted against Room no. 999"));
            lstTuples.Add(new Tuple<int, int, string>(2, 4, "Booking accepted against Room no. 998"));
            lstTuples.Add(new Tuple<int, int, string>(2, 4, "Booking accepted against Room no. 997"));
            lstTuples.Add(new Tuple<int, int, string>(2, 4, "Booking accepted against Room no. 996"));
            lstTuples.Add(new Tuple<int, int, string>(2, 4, "Booking accepted against Room no. 995"));
            lstTuples.Add(new Tuple<int, int, string>(2, 4, "Booking accepted against Room no. 994"));
            lstTuples.Add(new Tuple<int, int, string>(2, 4, "Booking accepted against Room no. 993"));
            lstTuples.Add(new Tuple<int, int, string>(2, 4, "Booking accepted against Room no. 992"));
            lstTuples.Add(new Tuple<int, int, string>(2, 4, "Booking accepted against Room no. 991"));
            lstTuples.Add(new Tuple<int, int, string>(2, 4, "Booking accepted against Room no. 990"));
            lstTuples.Add(new Tuple<int, int, string>(2, 4, "Booking accepted against Room no. 989"));
            lstTuples.Add(new Tuple<int, int, string>(2, 4, "Booking accepted against Room no. 988"));
            lstTuples.Add(new Tuple<int, int, string>(2, 4, "Booking accepted against Room no. 987"));
            lstTuples.Add(new Tuple<int, int, string>(2, 4, "Booking accepted against Room no. 986"));
            lstTuples.Add(new Tuple<int, int, string>(2, 4, "Booking accepted against Room no. 985"));
            lstTuples.Add(new Tuple<int, int, string>(2, 4, "Booking accepted against Room no. 984"));
            lstTuples.Add(new Tuple<int, int, string>(2, 4, "Booking accepted against Room no. 983"));
            lstTuples.Add(new Tuple<int, int, string>(2, 4, "Booking accepted against Room no. 982"));
            lstTuples.Add(new Tuple<int, int, string>(2, 4, "Booking accepted against Room no. 981"));

            foreach (var bookingReq in lstTuples)
            {
                string bookResult = Hotel.RoomAvailabilityCheck(1000, bookingReq.Item1, bookingReq.Item2, bookingSlot);
                Assert.AreEqual(bookingReq.Item3, bookResult);
            }
        }

        [TestMethod]
        public void TestMethod7()
        {
            //Room Size:1000
            var bookingSlot = Hotel.GetBookingData(1000, 365);

            List<Tuple<int, int, string>> lstTuples = new List<Tuple<int, int, string>>();
            lstTuples.Add(new Tuple<int, int, string>(257, 300, "Booking accepted against Room no. 1000"));
            lstTuples.Add(new Tuple<int, int, string>(257, 300, "Booking accepted against Room no. 999"));
            lstTuples.Add(new Tuple<int, int, string>(257, 300, "Booking accepted against Room no. 998"));
            lstTuples.Add(new Tuple<int, int, string>(257, 300, "Booking accepted against Room no. 997"));
            lstTuples.Add(new Tuple<int, int, string>(257, 300, "Booking accepted against Room no. 996"));
            lstTuples.Add(new Tuple<int, int, string>(257, 300, "Booking accepted against Room no. 995"));
            lstTuples.Add(new Tuple<int, int, string>(257, 300, "Booking accepted against Room no. 994"));
            lstTuples.Add(new Tuple<int, int, string>(257, 300, "Booking accepted against Room no. 993"));
            lstTuples.Add(new Tuple<int, int, string>(257, 300, "Booking accepted against Room no. 992"));
            lstTuples.Add(new Tuple<int, int, string>(257, 300, "Booking accepted against Room no. 991"));
            lstTuples.Add(new Tuple<int, int, string>(257, 300, "Booking accepted against Room no. 990"));
            lstTuples.Add(new Tuple<int, int, string>(257, 300, "Booking accepted against Room no. 989"));
            lstTuples.Add(new Tuple<int, int, string>(257, 300, "Booking accepted against Room no. 988"));
            lstTuples.Add(new Tuple<int, int, string>(257, 300, "Booking accepted against Room no. 987"));
            lstTuples.Add(new Tuple<int, int, string>(257, 300, "Booking accepted against Room no. 986"));
            lstTuples.Add(new Tuple<int, int, string>(257, 300, "Booking accepted against Room no. 985"));
            lstTuples.Add(new Tuple<int, int, string>(257, 300, "Booking accepted against Room no. 984"));
            lstTuples.Add(new Tuple<int, int, string>(257, 300, "Booking accepted against Room no. 983"));
            lstTuples.Add(new Tuple<int, int, string>(257, 300, "Booking accepted against Room no. 982"));
            lstTuples.Add(new Tuple<int, int, string>(257, 300, "Booking accepted against Room no. 981"));


            foreach (var bookingReq in lstTuples)
            {
                string bookResult = Hotel.RoomAvailabilityCheck(1000, bookingReq.Item1, bookingReq.Item2, bookingSlot);
                Assert.AreEqual(bookingReq.Item3, bookResult);
            }
        }
        [TestMethod]
        public void TestMethod8()
        {
            //Room Size:2
            var bookingSlot = Hotel.GetBookingData(2, 365);

            List<Tuple<int, int, string>> lstTuples = new List<Tuple<int, int, string>>();
            lstTuples.Add(new Tuple<int, int, string>(0, 0,"Booking accepted against Room no. 2"));
            lstTuples.Add(new Tuple<int, int, string>(0, 1, "Booking accepted against Room no. 1"));
            lstTuples.Add(new Tuple<int, int, string>(5, 5, "Booking accepted against Room no. 1"));
            lstTuples.Add(new Tuple<int, int, string>(4, 5, "Booking accepted against Room no. 2"));
            lstTuples.Add(new Tuple<int, int, string>(3, 3, "Booking accepted against Room no. 1"));
            lstTuples.Add(new Tuple<int, int, string>(2, 4, "Booking declined"));

            foreach (var bookingReq in lstTuples)
            {
                string bookResult = Hotel.RoomAvailabilityCheck(2, bookingReq.Item1, bookingReq.Item2, bookingSlot);
                Assert.AreEqual(bookingReq.Item3, bookResult);
            }
        }

    }
}
